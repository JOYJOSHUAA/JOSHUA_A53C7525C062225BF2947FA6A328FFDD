  # Define a list of student objects
students = [
      {'name': 'Alice', 'roll_number': 'A101', 'cgpa': 3.9},
      {'name': 'Bob', 'roll_number': 'B102', 'cgpa': 3.7},
      {'name': 'Charlie', 'roll_number': 'C103', 'cgpa': 3.5},
      {'name': 'David', 'roll_number': 'D104', 'cgpa': 3.8}
  ]

  # Sort the students based on CGPA
def sort_students(students):
  return sorted(students, key=lambda s: s['cgpa'], reverse=True)
for student in sort_students(students):
      print(f"Name: {student['name']}, Roll Number: {student['roll_number']}, CGPA: {student['cgpa']}")